function decreaseTimer(){
    timerId=setTimeout(decreaseTimer,1000)

    if(timer>0){
        timer--
        document.querySelector('#timer').innerHTML=timer
    }

    //time is 0
    if(timer==0){
        determineWinner({player,enemy,timerId})
    }

    //end game base on healt
    if(enemy.health<=0||player.health<=0){
        determineWinner({player,enemy,timerId})

    }
}

function rectangularCollision({rectangle1,rectangle2}){
    return(
        rectangle1.attackBox.position.x+rectangle1.attackBox.width>=
        rectangle2.position.x&&
        rectangle1.attackBox.position.x<=rectangle2.position.x+rectangle2.width&&
        rectangle1.attackBox.position.y+rectangle1.attackBox.height>=rectangle2.position.y&&
        rectangle1.attackBox.position.y<=rectangle2.position.y+rectangle2.height
        )
    }



function determineWinner({player,enemy,timerId}){
    clearTimeout(timerId)
    document.querySelector('#displayText').style.display='flex'

    if(player.health===enemy.health){
        document.querySelector('#displayText').innerHTML='Tie'
    }else if(player.health>enemy.health){
        document.querySelector('#displayText').innerHTML='Player I Wins'
    }else if(enemy.health>player.health){
        document.querySelector('#displayText').innerHTML='Player II Wins'
    }
}
